
League Icons - v1 2022-03-30 7:46pm
==============================

This dataset was exported via roboflow.ai on March 30, 2022 at 11:47 PM GMT

It includes 539 images.
Champ-Icons are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:


