
League Icons - v2 2022-03-30 7:56pm
==============================

This dataset was exported via roboflow.ai on March 30, 2022 at 11:56 PM GMT

It includes 185 images.
Champ-Icons are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


